document.documentElement.classList.add('js');

  // Nav scroll state
  const nav = document.getElementById('nav');
  const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 30);
  onScroll(); window.addEventListener('scroll', onScroll, {passive:true});

  // Mobile menu
  const menuBtn = document.getElementById('menuBtn');
  const navLinks = document.getElementById('navLinks');
  menuBtn.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');
    menuBtn.classList.toggle('open', open);
  });
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    navLinks.classList.remove('open'); menuBtn.classList.remove('open');
  }));

  // Active link on scroll
  const sections = [...document.querySelectorAll('section[id]')];
  const links = [...document.querySelectorAll('.nav-links a.link')];
  const spy = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){
        const id = e.target.id;
        links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#'+id));
      }
    });
  }, {rootMargin:'-45% 0px -50% 0px'});
  sections.forEach(s => spy.observe(s));

  // Reveal on scroll
  const revealObs = new IntersectionObserver((entries, obs) => {
    entries.forEach((e, i) => {
      if(e.isIntersecting){
        setTimeout(() => e.target.classList.add('in'), (i % 4) * 90);
        obs.unobserve(e.target);
      }
    });
  }, {threshold:.15});
  document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

  // Rotating roles
  const rotWords = ['Branding','Visual Identity','Logo Design','Art Direction'];
  const rotEl = document.getElementById('rot');
  const reduce = window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  if(!reduce){
    let ri = 0;
    setInterval(() => {
      ri = (ri + 1) % rotWords.length;
      rotEl.style.opacity = 0;
      setTimeout(() => { rotEl.textContent = rotWords[ri]; rotEl.style.opacity = 1; }, 250);
    }, 2400);
    rotEl.style.transition = 'opacity .25s ease';
  }

  // Count-up stats
  const counters = document.querySelectorAll('.n[data-count]');
  const countObs = new IntersectionObserver((entries, obs) => {
    entries.forEach(e => {
      if(!e.isIntersecting) return;
      const el = e.target;
      const target = +el.dataset.count;
      const suffix = el.dataset.suffix || '';
      if(reduce){ el.textContent = target + suffix; obs.unobserve(el); return; }
      let cur = 0; const step = Math.max(1, Math.ceil(target/60));
      const tick = () => {
        cur += step;
        if(cur >= target){ el.textContent = target + suffix; }
        else { el.textContent = cur + suffix; requestAnimationFrame(tick); }
      };
      tick(); obs.unobserve(el);
    });
  }, {threshold:.5});
  counters.forEach(c => countObs.observe(c));

  // Portfolio filter
  const filterBtns = document.querySelectorAll('.filters button');
  const works = document.querySelectorAll('.work');
  filterBtns.forEach(btn => btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const f = btn.dataset.filter;
    works.forEach(w => {
      const show = f === 'all' || w.dataset.cat === f;
      w.style.display = show ? '' : 'none';
    });
  }));

  // Contact form -> mailto
  const form = document.getElementById('contactForm');
  const note = document.getElementById('formNote');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const msg = form.msg.value.trim();
    if(!name || !email || !msg){ note.style.color = '#FF4D6D'; note.textContent = 'رجاءً عبّي كل الحقول.'; return; }
    const subject = encodeURIComponent('مشروع جديد من ' + name);
    const body = encodeURIComponent('الاسم: ' + name + '\nالبريد: ' + email + '\n\n' + msg);
    window.location.href = 'mailto:hello@example.com?subject=' + subject + '&body=' + body;
    note.style.color = '#2bd67b'; note.textContent = 'يتم فتح بريدك لإرسال الرسالة ✦';
    form.reset();
  });

  document.getElementById('year').textContent = new Date().getFullYear();
